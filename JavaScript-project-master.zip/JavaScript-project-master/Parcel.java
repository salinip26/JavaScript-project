public class Parcel {
	private String id;
	private char destination;
	private double weight;
	private double charge;
	public Parcel() {
		id=null;
		destination=0;
		weight=0.0;
		charge=0.0;
	}
	public void setdestination (char d) {
		destination = d;
	}
	public void setweight (double w) {
		weight = w;
	}
	public void setid (String a) {
		id = a;
	}

	
	public String getid () {
		return id;
	}
	public char getdestination () {
		return destination;
	}
	public double getweight () {
		return weight;
	}
	public double getcharge () {
		return charge;
	}
	public double calcCharge () {
		double weightCharge= 0;
		double destinationCharge= 0;
		if (weight<10) {
		     weightCharge = 1 * weight;}
		else {
			weightCharge = 2 * weight;}
		if (destination=='A') {
			destinationCharge = 5;}
		else if (destination=='B') {
			destinationCharge = 10;}
	    else{
		    destinationCharge = 15;}
		
		charge = weightCharge + destinationCharge;
		return charge;
		}
	public String toString() {
		return("\nId: "+ id+"\nDestination: "+destination+"\nWeight: "+weight);
	}
	}

