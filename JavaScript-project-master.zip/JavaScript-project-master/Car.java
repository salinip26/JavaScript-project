public class Car {
	String carName;
	String carColor;
	String carType;
	double carPrice;
	final double Import_Duty =0.6;
	public Car() {
		carName=null;
		carColor=null;
		carType=null;
		carPrice=0.0;
		
	}
	public void setcarName(String nm) {
		carName=nm;
	}
	public void setcarColor(String c) {
		carColor=c;
	}
	public void setcarType(String t) {
		carType=t;
	}
	public void setcarPrice(double p) {
		carPrice=p;
	}
	
	public String getcarName() {
		return carName;
	}
	public String getcarColor() {
		return carColor;
	}
	public String getcarType() {
		return carType;
	}
	public double getcarPrice() {
		return carPrice;
	}
	
	public double getPrice() {
		if ("import".equals(carType)) {
			carPrice= carPrice + 0.6 * carPrice;}
			return carPrice;
	}
	public String toString() {
		
			return ("Name: "+carName+"\nColor: "+carColor+"\nType: "+carType+"\nPrice: "+carPrice);
		}
	}

