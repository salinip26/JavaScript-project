import java.util.Scanner;
public class CarsInfo {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the number of array: ");
		int n = input.nextInt();
		Car[] info = new Car[n];
		
		for (int i=0;i<info.length; i++) {
			System.out.println("\nEnter name of car: ");
			String nm=input.next();
			System.out.println("Enter color of car: ");
			String c=input.next();
			System.out.println("Enter type of car: ");
			String t=input.next();
			System.out.println("Enter price of car: ");
			double p=input.nextDouble();
		info[i] = new Car();
		info[i].setcarName(nm);
		info[i].setcarColor(c);
		info[i].setcarType(t);
		info[i].setcarPrice(p);
		}
		System.out.println("\nThe name and price of cars: ");
		for(int i=0;i<info.length;i++) {
			System.out.println("Name: "+info[i].getcarName()+"\nPrice: "+info[i].getPrice());
		}
		System.out.println("\nThe cars with black color: ");
		for(int i=0; i<info.length; i++) {
			if("black".equals(info[i].getcarColor())) {
				System.out.println(info[i].toString());}}
		int y=0, z=0; 
		double pri=0, avg=0;
		for(int i=0; i<info.length; i++) {
		if ("local".equals(info[i].getcarType())) {
			pri = pri + info[i].getcarPrice() ;
			y++;}
		avg= pri/y;
		System.out.println("\nThe average price of local cars: "+ avg);
		
		if ("import".equals(info[i].getcarType())) {
			z++;}
		}
		System.out.println("\nThe number of local cars: "+y);
		System.out.println("\nThe number of import cars: "+z);
		int index= 0;
		for(int i=1;i<info.length; i++) {
			if(info[i].getcarPrice()>info[i-1].getcarPrice()) {
				index = i;}
			else {
				index=i-1;}
			}
		System.out.println("\nThe car with highest price: \n"+info[index].toString());
		}
	}

