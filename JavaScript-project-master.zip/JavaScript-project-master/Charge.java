import java.util.Scanner;
public class Charge {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		Parcel[] par = new Parcel[10];
		
		for(int i=0; i<par.length; i++) {
			System.out.println("Enter id of Parcel: ");
			String a = input.next();
			System.out.println("Enter destination (A, B, C): ");
			char d=input.next().charAt(0);
			System.out.println("Enter weight of Parcel: ");
			double w= input.nextDouble();
		par[i]= new Parcel();
		par[i].setid(a);
		par[i].setdestination(d);
		par[i].setweight(w);
		}
		System.out.println("The info about Parcel: \n");
		for(int i=0; i<par.length; i++) {
			System.out.println(par[i].toString()+"\n");}
		
		System.out.println("The transportation cost Parcel: \n");
		for(int i=0;i<par.length;i++) {
			System.out.println("id: "+par[i].getid()+"\nThe total transportation cost: "+par[i].calcCharge()+"\n");
		}
			
	}

}
